# Class to initialise and carry out a fit for one element.

from . import abutils
from . import fitabun
from . import __version__
import utils
import numpy
import os
import getpass
import datetime
import platform
import scipy.interpolate as ip

class setup:
    """Initialises a setup for abundance fitting of one element. 
    Input parameters will be stored in the class and a header will be written
    to the output file.
    
    Args:
        elemfit: Element to be fitted (e.g. 'Fe') 
        pfx    : List of parameters to keep fixed (e.g. ['LogVT','LogZ','Mg'])
        vfx    : Values of fixed parameters (e.g. ['USER', -1.0, +0.3])
        stelpar: List of stellar parameters
                 [[Teff1, Logg1, Rstar1, Nstar1, Logvt1, synt1],
                  [Teff2, Logg2, Rstar2, Nstar2, Logvt2, synt2],
                  ...
                 ]
                 Teff = effective temperature, logg = surface gravity,
                 Rstar = stellar radius, Nstar = number of stars in bin,
                 Logvt = log of microturbulent velocity (km/s),
                 synt = Synthesis method ('A9S' / 'A12S' / 'A9T' / 'MT')
        fnout  : Name of output file
        fnfnc(key)    : Function that returns name of input file for
                        a given key. The key can in principle be a variable
                        of any type, but will typically be an order
                        number or a string to denote different spectrograph
                        arms.
        rvfnc(wavelen) : Function of wavelength that returns radial velocity.
        sigfnc(wavelen): Function of wavelength that returns dispersion.
        fcfnc()        : Function that returns name of continuum file.
        vac2air : Perform vacuum-to-air conversion (True/False). 

    Methods:
        fit1p(self, key,rng,oname,fitfnc,fitord, nknots=5, 
              fitrng=[-1.0, 1.0], calcerr=True):  Fit one parameter
        close() : Close the output file
        
        """


    def __init__(self, 
                 elemfit, pfx, vfx, stelpar, fnout, fnfnc, rvfnc, 
                 sigfnc, fcfnc, vac2air=False):

        self._elem    = elemfit  # Element to fit (e.g. 'Fe')
        self._pfix    = pfx      # Names of fixed parameters
        self._vfix    = vfx      # Values of fixed parameters
        self._stelpar = stelpar  # Stellar parameters
#         self._fout    = fout     # Handle for output file (must be open for writing)
        self._setfname= fnfnc     # Function that returns input filename for
                                  # a given order
        self._rvfnc   = rvfnc     # Function that returns radial velocity
        self._sigfnc  = sigfnc    # Function that returns sigma
        self._fncont  = fcfnc     # Function that returns name of continuum file
        self._vac2air = vac2air   # Perform vacuum-to-air conversion?

        self._fout = open(fnout, 'w')

        self._fout.write('# ISPy3 %s\n' % __version__)
        self._fout.write('# %s@%s %s\n' % (getpass.getuser(), os.uname()[1], os.getcwd()))
        self._fout.write('# Python %s %s %s %s\n' % 
                  (platform.python_version(), os.uname()[0], 
                   os.uname()[2], str(datetime.datetime.now()))
                   )
        self._fout.write('# Fitting: %s\n' % elemfit)
        self._fout.write('#  BestFit       Lam1    Lam2   Result  err+   err-    Chisq   (sig)\n')
        self._fout.flush()
        os.fsync(self._fout)


    def fit1p(self, key,rng,oname,fitfnc,fitord, nknots=5, 
            fitrng=[-1.0, 1.0], calcerr=True):
        """Fit one parameter. 
        
        Args:
           key    : Key to select input spectrum. Will be passed to fnfnc()
                    to generate the name of the input file.
           rng    : Wavelength range (in AA) to fit (e.g. [4800, 4900])
           oname  : Name of output file with fitted and model spectra.
           fitfnc : Function used to fit continuum ('spline' / 'poly').
           order  : Order of fitting function.
           nknots : Number of internal knots when fitfnc='spline'.
           fitrng : Range of parameter value to search (e.g. [-1, 1])
           calcerr: Calculate errors? (True / False)
        """


        lamc = (rng[0] + rng[1])/2.
        lamstep = 0.01

        fncont = self._fncont()
        if (fncont is None):
            cont = None
        else:
            if (utils.ncol(fncont) < 5):
                lc, fc = numpy.loadtxt(fncont,usecols=(0,3), unpack=True)
                wgtc = numpy.ones(len(lc))
            else:
                lc, fc, wgtc = numpy.loadtxt(fncont,usecols=(0,3,4), unpack=True)
                
            cont = (lc, fc)
            fwgt = ip.interp1d(lc, wgtc)

        fname = self._setfname(key)
        rv    = self._rvfnc(lamc)
        sigsm = self._sigfnc(lamc)

        if (self._vac2air):
            with open(fname,'r') as f:
                data = abutils.vac2air(abutils.rvcorrect([s.split()[0:4] for s in f if s[0] != '#'], rv))
        else:
            with open(fname,'r') as f:
                data = abutils.rvcorrect([s.split()[0:4] for s in f if s[0] != '#'], rv)
            
        lam = [dd[0] for dd in data]

        if (cont is not None):   # Use the continuum flags for weights, too.
                                 # Multiply by already existing weights
            dtmp = []
            wgtlam = fwgt(lam)
            for _data, _wgtlam in zip(data, wgtlam):
                if len(_data) > 3:
                    dtmp.append([_data[0], _data[1], _data[2], _data[3]*_wgtlam])
                else:
                    dtmp.append([_data[0], _data[1], _data[2], _wgtlam])
            data = dtmp

        specrng = [max(rng[0], min(lam)+0.1), min(rng[1], max(lam)-0.1), lamstep]

        fitabun.SPECRNG = specrng
        fitabun.CFITFNC = fitfnc
        fitabun.NKNOTS = nknots
        fitabun.CFITORD = fitord

        stelpar = self._stelpar
        elem    = self._elem
        pfix    = self._pfix
        vfix    = self._vfix

        vfit,sigbst,vp,vm, chsq = fitabun.fit1par(data, stelpar, [elem], fitrng,
               pfix=pfix, vfix=vfix, sigsm=sigsm, cont=cont, calcerr=calcerr)

        fout = self._fout
        fout.write('%-15s %0.2f %0.2f %+0.3f %+0.3f %+0.3f %7.3f\n' % (oname, specrng[0], specrng[1], vfit, vp, vm, chsq))
        fout.flush()
        os.fsync(fout)
        os.system('cp -f fitabun.txt '+str(oname))


    def fitZ(self, key,rng,oname,fitfnc,fitord, nknots=5, 
            fitrng=[-4.0, 0.5], sigsm=None, calcerr=False):
        """Slightly modified version of fit1p, optimised for the 
           metallicity fits.
        
        Args:
           key    : Key to select input spectrum. Will be passed to fnfnc()
                    to generate the name of the input file.
           rng    : Wavelength range (in AA) to fit (e.g. [4800, 4900])
                    Will be truncated if wider than input spectrum.
           oname  : Name of output file with fitted and model spectra.
           fitfnc : Function used to fit continuum ('spline' / 'poly').
           order  : Order of fitting function.
           nknots : Number of internal knots when fitfnc='spline'.
           fitrng : Range of parameter value to search (e.g. [-4, 1])
           sigsm  : Smoothing value. If None, will be taken from
                    self._sigfnc(lamc). Can be a range, in which case
                    the best-fit value will be determined.
           calcerr: Calculate errors? (True / False)
        """

        fname = self._setfname(key)

        # Need an initial estimate of the wavelength range to get
        # the central wavelength of the bin

        rv5000 = self._rvfnc(5000.)
        lscl = 1 - rv5000/299792.458
        lam0 = numpy.loadtxt(fname, usecols=(0)) * lscl
        rng0 = [max(rng[0], min(lam0)+5.), min(rng[1], max(lam0)-5.)]

        lamc = (rng0[0] + rng0[1])/2.
        lamstep = 0.01

        fncont = self._fncont()
        
        if (fncont is None):
            cont = None
        else:
            if (utils.ncol(fncont) < 5):
                lc, fc = numpy.loadtxt(fncont,usecols=(0,3), unpack=True)
                wgtc = numpy.ones(len(lc))
            else:
                lc, fc, wgtc = numpy.loadtxt(fncont,usecols=(0,3,4), unpack=True)
                
            cont = (lc, fc)
            fwgt = ip.interp1d(lc, wgtc)

        rv    = self._rvfnc(lamc)
        if sigsm is None:
            sigsm = self._sigfnc(lamc)

        if (self._vac2air):
            with open(fname,'r') as f:
                data = abutils.vac2air(abutils.rvcorrect([s.split()[0:4] for s in f if s[0] != '#'], rv))
        else:
            with open(fname,'r') as f:
                data = abutils.rvcorrect([s.split()[0:4] for s in f if s[0] != '#'], rv)
            
        lam = [dd[0] for dd in data]

        if (cont is not None):   # Use the continuum flags for weights, too.
                                 # Multiply by already existing weights
            dtmp = []
            wgtlam = fwgt(lam)
            for _data, _wgtlam in zip(data, wgtlam):
                if len(_data) > 3:
                    dtmp.append([_data[0], _data[1], _data[2], _data[3]*_wgtlam])
                else:
                    dtmp.append([_data[0], _data[1], _data[2], _wgtlam])
            data = dtmp

        specrng = [max(rng[0], min(lam)+5.), min(rng[1], max(lam)-5.), lamstep]

        fitabun.SPECRNG = specrng
        fitabun.CFITFNC = fitfnc
        fitabun.NKNOTS = nknots
        fitabun.CFITORD = fitord

        stelpar = self._stelpar
        elem    = self._elem
        pfix    = self._pfix
        vfix    = self._vfix

        vfit,sigbst,vp,vm, chsq = fitabun.fit1par(data, stelpar, [elem], fitrng,
               pfix=pfix, vfix=vfix, sigsm=sigsm, cont=cont, calcerr=calcerr)

        fout = self._fout
        fout.write('%-15s %0.2f %0.2f %+0.3f %+0.3f %+0.3f %7.3f %7.3f\n' % (oname, specrng[0], specrng[1], vfit, vp, vm, chsq, sigbst))
        fout.flush()
        os.fsync(fout)
        os.system('cp -f fitabun.txt '+str(oname))



    def close(self):
        self._fout.write('# Done at %s\n' % str(datetime.datetime.now()))
        self._fout.close()
