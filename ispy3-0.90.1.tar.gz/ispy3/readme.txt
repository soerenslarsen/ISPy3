ISPY3 = Integrated-light Spectroscopy for PYthon3

Versions
0.90.0  - First version with a version number        (27.01.2020)
        - Fixed wrong link to 'diatomicsiwl.bin' in mkatm_a12().
        - Made references to 'molecules.dat' more consistent 
          (kurucz.molfile everywhere).
        - Set default vturb=2.0 in mkatm(), same as in mkatm_a12().
        - Write version info to various output files.
0.90.0a - Cleaned up the code a bit                  (29.01.2020)
0.90.1  - Different managing of molecular line lists (31.01.2020)
          We now have a list of files, 'syntherk.molfiles', 
          and a list of molecules 'syntherk.molecule_ids', which
          are in principle independent. Hence one can also
          just have one large list of diatomics (e.g. diatomics.asc).
