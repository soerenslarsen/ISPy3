from __future__ import print_function

from . import absetup
from . import kurucz
from . import __version__
import math
import scipy.interpolate as interpolate
import numpy
import os
import string
import subprocess
import stat
import logging
import struct

# atomdir = absetup.catpref+'/cats/Castelli/atoms_SLr/'
# atomdir = '${HOME}/cats/Castelli/atoms_modr/'
# atomdir = '${HOME}/cats/Kurucz/linelists/gfhyper100/'
# atomdir = '${HOME}/cats/Kurucz/linelists/gf18feb16mod/'
# atomdir = '${HOME}/cats/Kurucz/linelists/gf05jun16/'
# atomdir = '${HOME}/cats/Kurucz/linelists/gf18feb16modr/'
# atomdir = '${HOME}/cats/Kurucz/linelists/gf08oct17sl/'
# atomdir = absetup.catpref+'/cats/Kurucz/linelists/gf08oct17slr/'
# atomdir = absetup.catpref+'/cats/Kurucz/linelists/gf08oct17slr_e/'
atomdir = absetup.catpref+'/cats/linelists/atoms/ssl/SYNTHE/'
# atomdir = absetup.catpref+'/cats/Kurucz/linelists/gf08oct17sl_abo/'
moldir  = absetup.catpref+'/cats/Kurucz/molecules/20apr2016/'
preddir = absetup.catpref+'/cats/Castelli2015/linelists/'

atomlines = [
  ['gf0150', 1000., 1500.],
  ['gf0200', 1500., 2000.],
  ['gf0300', 2000., 3000.],
  ['gf0400', 3000., 4000.],
  ['gf0500', 4000., 5000.],
  ['gf0600', 5000., 6000.],
  ['gf0800', 6000., 8000.],
  ['gf1200', 8000., 12000.],
  ['gf3000', 12000., 30000.] 
]

# One large file with all diatomic molecules (except TiO)
# molfiles = ['diatomics.asc']

# Individual molecular line lists
molfiles = [
  'chmasseron.asc',
  'mgh15082018.asc',
  'nhaxCas.asc',
  'nhcaCas.asc',
  'ohupdate.asc',
  'sihaxsightly12012018.asc',
  'sihxxsightly12012018.asc',
  'h2.asc',
  'h2xx.asc',
  'c2ax.asc',
  'c2ba.asc',
  'c2dabrookek.asc',
  'c2ea.asc',
  'cnaxbrookek.asc',
  'cnbxbrookek.asc',
  'cnxx12brooke.asc',
  'coax.asc',
  'coxx.asc',
  'sioax.asc',
  'sioex.asc',
  'sioxx.asc',
  'cah.asc',
  'fehfx.asc',
  'voax.asc',
  'vobx.asc',
  'vocx.asc',
]


molecule_ids = [
  ['H2',  ' 101'],
  ['CH',  ' 106'],
  ['NH',  ' 107'],
  ['OH',  ' 108'],
  ['NaH', ' 111'],
  ['MgH', ' 112'],
  ['AlH', ' 113'],
  ['SiH', ' 114'],
  ['CaH', ' 120'],
  ['TiH', ' 122'],
  ['CrH', ' 124'],
  ['FeH', ' 126'],
  ['C2',  ' 606'],
  ['CN',  ' 607'],
  ['CO',  ' 608'],
  ['AlO', ' 813'],
  ['SiO', ' 814'],
  ['CaO', ' 820'],
  ['TiO', ' 822'],
  ['VO',  ' 823']
]


def do_synbeg_sel(lam1, lam2, step, tio=True, predicted=False, nlte=False, initdir='.', elements=['All'], molecules=['All'], select=True):

# Individual selected elements and molecules can be specified.
#
# select=True/False specifies whether the selection of line data should be
# done and written to temporary files (gfsel.synthe, molselN.synthe). If False,
# it is assumed that this has already been done.

# The NLTE switch in principle allows different initialization procedures
# for NLTE and LTE atmospheres. The IFNLTE switch in the input to
# SYNBEG can be set to 0 or 1. However, not clear this makes any
# difference. So for now, the nlte option is ignored.

    idir = os.path.abspath(initdir)

    print('SYNBEG: Initializing line list for %0.2f < LAMBDA < %0.2f\n' % (lam1, lam2))
    logging.debug('SYNBEG: Initializing line list for %0.2f < LAMBDA < %0.2f' % (lam1, lam2) )


    if select:

    # Select the relevant atomic line data files
    
        for j in range(len(atomlines)):
            if (lam1 >= atomlines[j][1] and lam1 <= atomlines[j][2]):
                j1 = j
                
            if (lam2 >= atomlines[j][1] and lam2 <= atomlines[j][2]):
                j2 = j
                
    # Select only the specified elements (default: All) and write to gfsel.synthe
                
        zsel = []
        for elem in [('H', 1, 0.92156), ('He', 2, 0.078438)] + absetup.stdabun:
            if elem[0] in elements or 'All' in elements:
                zsel.append(elem[1])
                print('Including %s' % elem[0])
                logging.debug('Including %s' % elem[0])
            else:
                print('Skipping %s' % elem[0])
                logging.debug('Skipping %s' % elem[0])
    
                
        fgf = open(idir+'/gfsel.synthe','w')
        for j in range(j1, j2+1):
            p = os.path.expandvars('%s%s.100' % (atomdir, atomlines[j][0]))
            with open(p,'r') as f:
                for l in f:
                    szrd  = l[19:21]
                    zrd  = int(szrd)
                    if (zrd in zsel): fgf.write(l)
    
        fgf.close()
    
    # Select the specified molecules (default: All) and write to molselN.synthe
    # where N=1, 2, 3, ...
    # The programme rmolecasc.exe needs the list to be sorted, therefore we write
    # the input data to separate files
    
        msel = []
        
        for _molID in molecule_ids:
             if _molID[0] in molecules or 'All' in molecules:
                 msel.append(_molID[1])
                 print('Including molecule: %s' % _molID[0])
                 logging.debug('Including molecule: %s' % _molID[0])
             else:
                 print('Skipping molecule: %s' % _molID[0])
                 logging.debug('Skipping molecule: %s' % _molID[0])
    
        nmoltmp = 0
        for _mfile in molfiles:
            nmoltmp += 1
            fmol = open(idir+'/molsel%d.synthe' % nmoltmp,'w')
    
            p = os.path.expandvars('%s%s' % (moldir, _mfile))
            print('Reading file: %s' % p)
            logging.debug('Reading file: %s' % p)
    
            with open(p,'r') as f:
                for l in f:
                    lam   = float(l[0:10]) * 10.
                    sicode = l[48:52]
                    if (lam > lam1-10) and (lam < lam2+10):
                        if (sicode in msel): fmol.write(l)
            fmol.close()

    else:   # That is, if not select
        nmoltmp = len(molfiles)            

# ISPy3 convention is AA for wavelengths, but Kurucz codes use nm
    
    lam1nm = lam1/10. 
    lam2nm = lam2/10
    R = lam1/step
    
    if (tio):
        extension = 'tio'
    else:
        extension = 'notio'

    ifnlte = 0    
#    if (nlte):
#        ifnlte = 1
#        print('Initializing for NLTE')
#        logging.debug('Initializing for NLTE')
#        extension = extension + '-nlte'
#    else:
#        ifnlte = 0
#        print('Initializing for LTE')
#        logging.debug('Initializing for LTE')
#        extension = extension + '-lte'

# Set up the .com file to read the line data
    
    f = open(idir+'/synbeg.com','w')
#    f.write('#!/bin/csh\n')
    f.write('#!/bin/bash\n')
    f.write('cd '+idir+'\n')
    f.write('\\rm -f fort.*\n')
    f.write(absetup.binpath+'synbeg.exe<<EOF>'+idir+'/synbeg.out\n')
#    f.write('AIR       520.0     540.0     500000.   0.     0          10 .001         0   00\n')
    f.write('AIR       %-9.2f %-9.2f %-9.1f 0.     %i          10 .001         0   00\n' % (lam1nm, lam2nm, R, ifnlte))
    f.write('AIRorVAC  WLBEG     WLEND     RESOLU    TURBV  IFNLTE LINOUT CUTOFF        NREAD\n')
    f.write('EOF\n')
    
# Atomic line list:
    
    f.write('ln -fs '+idir+'/gfsel.synthe fort.11\n')
    f.write(absetup.binpath+'rgfalllinesnew.exe>'+idir+'/rgfalllinesnew.out\n')

    f.write('\\rm -f fort.11\n')

# Predicted lines:

    if (predicted):
        print('Including predicted lines')
        logging.debug('Including predicted lines')
        f.write('ln -fs '+preddir+'/fclowlines.bin fort.11\n')
        f.write(absetup.binpath+'rpredict.exe>'+idir+'/predictedlow.out\n')
        f.write('\\rm -f fort.11\n')
        f.write('ln -fs '+preddir+'/fchighlines.bin fort.11\n')
        f.write(absetup.binpath+'rpredict.exe>'+idir+'/predictedhigh.out\n')
        f.write('\\rm -f fort.11\n')
    else:
        print('Skipping predicted lines')
        logging.debug('Skipping predicted lines')

# Molecular line list:

    print('Reading molecules')
    logging.debug('Reading molecules')
    for imol in range(1,nmoltmp+1):
        f.write('ln -fs '+idir+'/molsel%d.synthe fort.11\n' % imol)
        f.write(absetup.binpath+'rmolecasc.exe>'+idir+'/rmolecasc%d.out\n' % imol)
        f.write('\\rm -f fort.11\n')
 
#  A couple of special cases handled separately:
    
    if ('TiO' in molecules or 'All' in molecules):   
        print('Including TiO')    
        logging.debug('Including TiO')    
        if (tio):
            print('Including Schwenke TiO lines')
            logging.debug('Including Schwenke TiO lines')
            f.write('ln -fs '+moldir+'/tioschwenke.bin fort.11\n')
            f.write('ln -fs '+moldir+'/eschwenke.bin fort.48\n')
            f.write(absetup.binpath+'rschwenk.exe>'+idir+'/rschwenk.out\n')
            f.write('\\rm -f fort.11\n')
            f.write('\\rm -f fort.48\n')
        else:
            print('Skipping Schwenke TiO lines')
            logging.debug('Skipping Schwenke TiO lines')
    else:
        print('Skipping TiO')
        logging.debug('Skipping TiO')
    
    if ('H2O' in molecules or 'All' in molecules):
        print('Including H2O')
        logging.debug('Including H2O')
        f.write('ln -fs '+moldir+'/h2ofastfix.bin fort.11\n')
        f.write(absetup.binpath+'rh2ofast.exe>'+idir+'/h2ofast.out\n')
        f.write('\\rm -f fort.11\n')
    else:
        print('Skipping H2O')
        logging.debug('Skipping H2O')

    f.write('mv fort.20 '+idir+'/fort20.%s\n' % (extension))
    f.write('mv fort.19 '+idir+'/fort19.%s\n' % (extension))
    f.write('mv fort.93 '+idir+'/fort93.%s\n' % (extension))
    f.write('mv fort.14 '+idir+'/fort14.%s\n' % (extension))
    f.write('mv fort.12 '+idir+'/fort12.%s\n' % (extension))

    f.close()
    
#    os.system('source synbeg.com')

    os.chmod(idir+'/synbeg.com',stat.S_IXUSR | stat.S_IRUSR | stat.S_IWUSR)
    p = subprocess.Popen(idir+'/synbeg.com')
    os.waitpid(p.pid,0)

    
def synbeg(lam1, lam2, step, predicted=False, initdir='.', elements=['All'], molecules=['All']):

# Set up the input files for SYNTHE. They will be placed in the
# directory 'initdir'.
# Two sets of files are generated, with and without TiO, respectively.
# The appropriate set will then be used by 'synthespec', depending
# on the temperature.

    do_synbeg_sel(lam1, lam2, step, tio=True, predicted=predicted, nlte=False, initdir=initdir, elements=elements, molecules=molecules, select=True)
    do_synbeg_sel(lam1, lam2, step, tio=False, predicted=predicted, nlte=False, initdir=initdir, elements=elements, molecules=molecules, select=False)
    


def mkmod(m, atmname, modname, atoms=[], abun=[], vturb=None, surfaceflux=False):

# Set up a model atmosphere input file for SYNTHE.
# This entails adding a special header to a normal ATLAS9 or ATLAS12
# model atmosphere and modifying the abundances according to the 'atoms' and
# 'abun' parameters.
# 

#    fh = 0.92156
    fhe = 0.07834      # Corresponds to Y=0.248; Grevesse & Sauval 1998
#    if ('H' in atoms):  fh = abun[atoms.index('H')]
    if ('He' in atoms): fhe = abun[atoms.index('He')]
    
# First find the H fraction

    fh, mcorr = kurucz.fhcorr(m, atoms, abun)

# If the user insists:        

    if ('H' in atoms):  fh = abun[atoms.index('H')]

# Write the header for SYNTHE    

    fmod = open(modname,'w')
    if (surfaceflux):
        fmod.write('SURFACE FLUX\n')
    else:
        fmod.write('SURFACE INTENSI 17 1.,.9,.8,.7,.6,.5,.4,.3,.25,.2,.15,.125,.1,.075,.05,.025,.01\n')
        
    fmod.write('ITERATIONS 1 PRINT 2 PUNCH 2\n')
    fmod.write('CORRECTION OFF\n')
    fmod.write('PRESSURE OFF\n')
    fmod.write('READ MOLECULES\n')
    fmod.write('MOLECULES ON\n')

    fatm = open(atmname,'r')
    s = fatm.readline()
    atlas12 = False
    
#    for s in file(atmname):
    while (s != ''):
        ss = s.split()
        if (ss[0] == 'TEFF'): 
            teff = float(ss[1])
            slte = ss[-1]
            nlte = (slte == 'NLTE')
            
        if (ss[0] == 'TITLE'):
            if ('ATLAS12' in s): atlas12 = True    
                            
        if ('ABUNDANCE TABLE' in s):   # Skip these ATLAS12 model cards
            while not ('READ DECK' in s): s = fatm.readline()    
                         
        if ('ABUNDANCE SCALE' in s):
            mmod = math.log10(float(ss[2]))
            dm = mmod - m
            if (abs(dm) > 0.01) and not atlas12:
                print('WARNING: Using [m/H]=%0.3f atmosphere for [m/H]=%0.3f spectrum' % (mmod, m))
                logging.debug('Using [m/H]=%0.3f atmosphere for [m/H]=%0.3f spectrum' % (mmod, m))

#            fmod.write('ABUNDANCE SCALE %9.5f %s' % (10**m, string.rstrip(s[26:],'\n')))
            fmod.write('ABUNDANCE SCALE %9.5f ABUNDANCE CHANGE 1 %7.5f 2 %8.6f' % (10**(m+mcorr), fh, fhe))
           
           
            for j in range(len(absetup.stdabun)):
                if (j % 5 == 0):
                    fmod.write('\n ABUNDANCE CHANGE')
               
                ida = 0.
                ielem = absetup.stdabun[j][1]
                selem = absetup.stdabun[j][0]
               
                if (ielem in atoms):
                    ida = abun[atoms.index(ielem)]
                   
                if (selem in atoms):
                    ida = abun[atoms.index(selem)]
    
                iabun = absetup.stdabun[j][2] + ida
                fmod.write('%3d %7.3f' % (ielem, iabun))
           
            fmod.write('\n')    
        elif ('READ DECK' in s):
                    
            fmod.write(s)
            ss = s.split()
            nrd = int(ss[2])
            logging.debug('Now read %d layers:' % nrd)
            for j in range(nrd):
                s = fatm.readline()
                logging.debug(s)
#                ss = s.split()
#                print len(s)
                if len(s) > 100:
                    ss = list(struct.unpack_from('15s9s10s10s10s10s10s10s10s10s',s.encode()))
                    fstr = '%15.8E%9.1F%10.3E%10.3E%10.3E%10.3E%10.3E%10.3E%10.3E%10.3E\n'
                else:
                    ss = list(struct.unpack_from('15s9s10s10s10s10s10s10s10s',s.encode()))
                    fstr = '%15.8E%9.1F%10.3E%10.3E%10.3E%10.3E%10.3E%10.3E%10.3E\n'
                     
                if (vturb is not None):
                    ss[6] = vturb*1e5
                fmod.write(fstr % tuple([float(x) for x in ss])) 
        else:
            if not ('ABUNDANCE CHANGE' in s):
                fmod.write(s)
        logging.debug('Reading next line:')
        s = fatm.readline()  
        logging.debug(s)  
          
           
    fmod.close()
    fatm.close()
    return (teff, nlte)


def synthespec(m, atmname, spname, vturb=2.0, vrot=0.01, 
               atoms=[], abun=[], initdir='.', workdir='.', 
               wait=True, surfaceflux=False):

# Spectral synthesis using SYNTHE.
# The input files must have been initialized with 'synbeg' and should
# be present in the 'initdir' directory. They will be copied to
# 'workdir' and renamed so the original files will remain intact.

# atoms[] is a list of elements and abun[] the corresponding offsets
# in their abundances with respect to the reference (absetup.stdabun).
# atoms[] can be given either as atomic numbers or the element
# abbreviations (i.e., ['O', 'Mg'] and [8, 12] are equally valid). 
# If surfaceflux=True, set the 'SURFACE FLUX' card and do not use
# ROTATE. Otherwise, set 'SURFACE INTENSITY' to the 17 angles and use
# ROTATE to calculate fluxes. The result should be the same if there
# is no rotation.

    cwd = os.getcwd()
    wdir = os.path.abspath(workdir)
    idir = os.path.abspath(initdir)

# First set up the model atmosphere file, using output from an ATLAS9 run

    teff, nlte = mkmod(m, atmname, wdir+'/SPEC.mod', atoms=atoms, 
                       abun=abun, vturb=vturb, surfaceflux=surfaceflux)

# The TiO lines can be skipped for hotter stars, this will speed up things
# very significantly

    if (teff > 4500):
        extension = 'notio'
        print('Teff = %0.0f K for %s: Excluding TiO lines' % (teff, atmname))
        logging.debug('Teff = %0.0f K for %s: Excluding TiO lines' % (teff, atmname))
    else:
        extension = 'tio'
        print('Teff = %0.0f K for %s: Including TiO lines' % (teff, atmname))
        logging.debug('Teff = %0.0f K for %s: Including TiO lines' % (teff, atmname))
        
# Was the model atmosphere computed with NLTE?        
#    if (nlte):
#        extension = extension+'-nlte'
#        print('%s is NLTE model' % (atmname))
#        logging.debug('%s is NLTE model' % (atmname))
#    else:
#        extension = extension+'-lte'
#        print('%s is LTE model' % (atmname))
#        logging.debug('%s is LTE model' % (atmname))

        
# Then set up the COM file to run SYNTHE. This will be put in 'workdir'    
    
    fc = open(wdir+'/synthe.com','w')
#    fc.write('#!/bin/csh\n')
    fc.write('#!/bin/bash\n')
    fc.write('cd '+wdir+'\n')
#    fc.write('ln -fs '+absetup.catpref+'/cats/Castelli/molecules.dat fort.2\n')
    fc.write('ln -fs '+kurucz.molfile+' fort.2\n')
#    fc.write('ln -fs '+absetup.catpref+'/cats/Castelli/continua.dat fort.17\n')
    fc.write('ln -fs '+kurucz.contfile+' fort.17\n')
    fc.write(absetup.binpath+'xnfpelsyn.exe< "SPEC.mod" >xnfpelsyn.out\n')
    fc.write('mv fort.10 xnftSPEC.dat\n')
    fc.write('\\rm -f fort.*\n')
    fc.write('ln -fs xnftSPEC.dat fort.10\n')
    
    fc.write('cp  '+idir+'/fort20.%s fort.20\n' % (extension))
    fc.write('cp  '+idir+'/fort19.%s fort.19\n' % (extension))
    fc.write('cp  '+idir+'/fort93.%s fort.93\n' % (extension))
    fc.write('cp  '+idir+'/fort14.%s fort.14\n' % (extension))
    fc.write('cp  '+idir+'/fort12.%s fort.12\n' % (extension))

#    fc.write('ln -fs '+absetup.catpref+'/cats/Castelli/he1tables.dat fort.18\n')
    fc.write('ln -fs '+kurucz.he1file+' fort.18\n')
    fc.write(absetup.binpath+'synthe.exe>synthe.out\n')
#    fc.write('ln -fs '+absetup.catpref+'/cats/Castelli/molecules.dat fort.2\n')
    fc.write('ln -fs '+kurucz.molfile+' fort.2\n')
    fc.write('cat <<EOF >fort.25\n')
    fc.write('0.0       0.        1.        0.        0.        0.        0.        0.\n')
    fc.write('0.\n')
    fc.write('RHOXJ     R1        R101      PH1       PC1       PSI1      PRDDOP    PRDPOW\n')
    fc.write('EOF\n')
    fc.write(absetup.binpath+'spectrv.exe<SPEC.mod>spectrv.out\n')
    fc.write('mv -f fort.7 SPEC.dat\n')
    
    fc.write('\\rm -f fort.*\n')
    fc.write('ln -fs SPEC.dat fort.1\n')

    if (not surfaceflux):
        fc.write(absetup.binpath+'rotate.exe<<EOF>rotate.out\n')
        fc.write('    1\n')
        fc.write('%0.2f\n' % (vrot))
        fc.write('EOF\n')
        fc.write('mv -f ROT1 SPECvr2.dat\n')
#    fc.write('ln -fs SPECvr2.dat fort.21\n')
#    fc.write('broaden.exe<<EOF>broaden.out\n')
#    fc.write('GAUSSIAN  100000.   RESOLUTION\n')
#    fc.write('EOF\n')
#    fc.write('mv -f fort.22 SPECvr2br.bin\n')
        fc.write('\\rm -f fort.*\n')
        fc.write('ln -fs SPECvr2.dat fort.1\n')
    
    fc.write(absetup.binpath+'converfsynnmtoa.exe\n')
    fc.write('mv -f fort.2 SPECvr2.asc\n')
    fc.write('\\rm -f fort.*\n')
    
    fc.write('echo \'# ISPy3 %s\' > %s\n' % (__version__, cwd+'/'+spname))
    fc.write('echo \'# SYNTHE\' >> %s\n' % (cwd+'/'+spname))
    fc.write('echo \'# atomdir = %s\' >> %s\n' % (atomdir, cwd+'/'+spname))
    fc.write('echo \'# moldir  = %s\' >> %s\n' % (moldir,  cwd+'/'+spname))
    fc.write('echo \'# atmname = %s\' >> %s\n' % (atmname, cwd+'/'+spname))
    fc.write('''awk '{if (l++ < 2) printf("# %s\\n",$0); else printf("%0.4f  %0.4f  %0.4e\\n",$1,$4,$2)}' SPECvr2.asc >>'''+cwd+'/'+spname+'\n')

    fc.close()
    
    print('SYNTHE: Computing synthetic spectrum '+spname)
    logging.debug('SYNTHE: Computing synthetic spectrum %s' % spname)
    os.chmod(wdir+'/synthe.com',stat.S_IXUSR | stat.S_IRUSR | stat.S_IWUSR)

    p = subprocess.Popen(wdir+'/synthe.com')

    if (wait):
        os.waitpid(p.pid,0)
    else:
        return p
    


def idlines(m, atmname, idname, lam1, lam2, R=100000., atoms=[], abun=[], decrowd=True):

    teff, nlte = mkmod(m, atmname, 'SPEC.mod', atoms=atoms, abun=abun)
        
    lam1nm = lam1/10.
    lam2nm = lam2/10.

    for j in range(len(atomlines)):
        if (lam1 >= atomlines[j][1] and lam1 <= atomlines[j][2]):
            j1 = j

        if (lam2 >= atomlines[j][1] and lam2 <= atomlines[j][2]):
            j2 = j
            
    if (nlte):
        ifnlte = 1
    else:
        ifnlte = 0        

    fl = open('gftmp.txt','w')
    for j in range(j1, j2+1):
#        for s in file(absetup.catpref+'/cats/Castelli/atoms/'+atomlines[j][0]+'.100'):
        with open(atomdir+atomlines[j][0]+'.100','r') as f:
            for s in f:
                lam = float(s[0:11]) * 10.
                if (lam > lam1 and lam < lam2): fl.write(s)
    fl.close()
    
    with open('gftmp.txt','r') as f:
        elem = list(set([float(s[19:24]) for s in f]))
    elem.sort()
#    print elem

    extlst = ['I','II','III','IV','V','VI','VII','VIII','IX','X']
    
    fout = open(idname,'w')
    
    for ee in elem:
        eid = int(ee)
        eion = int((ee - eid)*100.1)
        if (eid == 1):
            name = 'H'
        elif (eid == 2):
            name = 'He'
        else:
            for kk in absetup.stdabun:
                if (kk[1] == eid): name = kk[0]
        
        if (eion < 10):
            ext = extlst[eion]
        else:
            ext = '*'
            
        print(ee, eid, eion, name, ext)
        
        elam = []
        fl2 = open('gfe.txt','w')

        with open('gftmp.txt','r') as f:
            for s in f:
                ef = float(s[19:24])
                if (ef == ee): 
                    fl2.write(s)
                    elam.append(float(s[0:11])*10.)
                
        fl2.close()    
        
# Run synthe for this element
        
        f = open('idsynthe.com','w')

#        f.write('ln -fs '+absetup.catpref+'/cats/Castelli/molecules.dat fort.2\n')
        f.write('ln -fs '+kurucz.molfile+' fort.2\n')
#        f.write('ln -fs '+absetup.catpref+'/cats/Castelli/continua.dat fort.17\n')
        f.write('ln -fs '+kurucz.contfile+' fort.17\n')
        f.write(absetup.binpath+'xnfpelsyn.exe< "SPEC.mod" >xnfpelsyn.out\n')
        f.write('mv fort.10 xnftSPEC.dat\n')
        f.write('\\rm -f fort.*\n')
        f.write('ln -fs xnftSPEC.dat fort.10\n')
        f.write(absetup.binpath+'synbeg.exe<<EOF>synbeg.out\n')
#    f.write('AIR       520.0     540.0     500000.   0.     0          10 .001         0   00\n')
        f.write('AIR       %-9.2f %-9.2f %-9.1f 0.     %i          10 .001         0   00\n' % (lam1nm, lam2nm, R, ifnlte))
        f.write('AIRorVAC  WLBEG     WLEND     RESOLU    TURBV  IFNLTE LINOUT CUTOFF        NREAD\n')
        f.write('EOF\n')
    
        f.write('ln -fs gfe.txt fort.11\n')
        f.write(absetup.binpath+'rgfalllinesnew.exe>gfe.out\n')
        f.write('\\rm -f fort.11\n')   

#        f.write('ln -fs '+absetup.catpref+'/cats/Castelli/he1tables.dat fort.18\n')
        f.write('ln -fs '+kurucz.he1tables+' fort.18\n')
        f.write(absetup.binpath+'synthe.exe>synthe.out\n')
#        f.write('ln -fs '+absetup.catpref+'/cats/Castelli/molecules.dat fort.2\n')
        f.write('ln -fs '+kurucz.molfile+' fort.2\n')
        f.write('cat <<EOF >fort.25\n')
        f.write('0.0       0.        1.        0.        0.        0.        0.        0.\n')
        f.write('0.\n')
        f.write('RHOXJ     R1        R101      PH1       PC1       PSI1      PRDDOP    PRDPOW\n')
        f.write('EOF\n')
        f.write(absetup.binpath+'spectrv.exe<SPEC.mod>spectrv.out\n')
        f.write('mv -f fort.7 SPEC.dat\n')
        f.write('ln -fs SPEC.dat fort.1\n')
        f.write(absetup.binpath+'rotate.exe<<EOF>rotate.out\n')
        f.write('    1\n')
        f.write('2.\n')
        f.write('EOF\n')
        f.write('mv -f ROT1 SPECvr2.dat\n')
        f.write('\\rm -f fort.*\n')

        f.write('ln -fs SPECvr2.dat fort.1\n')
        f.write(absetup.binpath+'converfsynnmtoa.exe\n')
        f.write('mv -f fort.2 SPECvr2.asc\n')
        f.write('\\rm -f fort.*\n')
    
        f.write('''awk '{if (l++ > 1) printf("%0.4f  %0.4f  %0.4e\\n",$1,$4,$2)}' SPECvr2.asc > specid.txt\n''')
        f.close()
        
        os.system('source idsynthe.com')
        
# Now find out which entries in the line list produce a significant line in the spectrum

        with open('specid.txt','r') as ff:
            slam = numpy.array([float(s.split()[0]) for s in ff])

        with open('specid.txt','r') as ff:
            sflx = numpy.array([float(s.split()[1]) for s in ff])
        
        if (decrowd):
           for j in range(1,len(slam)-1):
               if (sflx[j] < sflx[j-1]) and (sflx[j] < sflx[j+1]):
                   dlam = list(abs(numpy.array(elam) - slam[j]))
                   dmin = min(dlam)
                   wdmin = dlam.index(dmin)
                   fmin = sflx[j]
                   fout.write('%10.3f %6.2f %6.4f %2s %-5s\n' % (elam[wdmin], ee, fmin, name, ext))
        else:        
            for ll in elam:
                dlam = list(abs(slam - ll))
                dmin = min(dlam)
                wdmin = dlam.index(dmin)
                fmin = sflx[wdmin]
                fout.write('%10.3f %6.2f %6.4f %2s %-5s\n' % (ll, ee, fmin, name, ext))
            
    fout.close()
        


def calcew(atmname, elem, lam, nablog, minlog, dablog, logvt=0.300, lamtol=0.001, lines=None):
# Input:
#  atmname = name of ATLAS model atmosphere
#  elem    = element code, e.g. 11.00 = Na I
#  lam     = wavelength of line, in AA
#  nablog  = Number of abundance offsets (with respect to value in atmosphere)
#  minlog  = Minimum relative abundance
#  dablog  = Log abundance step
#  logvt   = Log of microturbulent velocity (in km/s)
#  lamtol  = Tolerance when matching lambda to line list, in AA
#  lines   = File with line data (Kurucz format). Default: Castelli list
# Returns:
#  Array of equivalent widths (in mAA).

    if (nablog > 99):
        print('ERROR: NABLOG must be less than 100')
        raise Exception('Error: NABLOG too large')
        
    f = open('inpew.com','w')
    f.write('\\rm -f fort.*\n')
    if (lines is None):
        for j in range(len(atomlines)):
            if (lam >= atomlines[j][1] and lam <= atomlines[j][2]):
                f.write('ln -s '+absetup.catpref+'/cats/Castelli/atoms_SLr/'+atomlines[j][0]+'.100 fort.10\n')
    else:
        f.write('ln -s '+lines+' fort.10\n')
 
    f.write(absetup.binpath+'inpw_sl.exe<<EOF>inpwidth.out\n')
        
    f.write('NoName\n')           # Star name
    f.write('1\n')                # VTUR(bulence)? (yes=1/no=0)
    f.write('1\n')                # Number N of the microturb. velocities (NMAX=3)
    vturb = 10**logvt
    f.write('%0.2f\n' % vturb)    # Values of the N microturb. velocities
    f.write('0\n')                # Is some line file already existing?(yes=1/no=0)
    f.write('0\n')                # LINE ? (yes=1/no=0)
    f.write('0\n')                # PROF(ile)? (yes=1/no=0)
    f.write('0\n')                # AVER(age)? (yes=1/no=0)
    f.write('1\n')                # CURV(e)? (yes=1/no=0)
    f.write('%d %0.3f %0.3f\n' % (nablog, minlog, dablog))
    f.write('1\n')                # LINE ? (yes=1/no=0)
    f.write('%0.4f\n' % (lam/10)) # wavelength (in Nm: es. 4000A=400.0 Nm)
#    if not (lines==None):
    f.write('%0.4f\n' % (lamtol/10)) # matching tolerance (in Nm)
    f.write('10\n')               # equivalent width (in Pm: es. 200 mA=20.0 Pm)
    f.write('%0.2f\n' % elem)     # Code
    f.write('0\n')                # LINE ? (yes=1/no=0)
    f.write('1\n')                # end of data for the lines? (yes=1/no=0)
    f.write('%s\n' % atmname)     # Name of the model file
    f.write('EOF\n')
    
    f.write('mv fort.1 inpwidth.dat\n')
    f.write('\\rm -f fort.*\n')
    f.close()
    
    os.system("bash -c 'source inpew.com'")
    
    f2 = open('width9.com','w')
    f2.write('\\rm -f fort.*\n')
#    f2.write('ln -s '+absetup.catpref+'/cats/Castelli2015/molecules.dat fort.2\n')
    f2.write('ln -s '+kurucz.molfile+' fort.2\n')
    f2.write(absetup.binpath+'width9sl.exe < inpwidth.dat > width9.out\n')
    f2.write('\\rm -f fort.*\n')
    f2.close()

    os.system("bash -c 'source width9.com'")
    
    fw = open('width9.out','r')
    s = ''
#    while (not 'NoName' in s): s = fw.readline()
    while not ('VTURB  ABUND' in s): s = fw.readline()
#    s = fw.readline()

    ss = s.split()
    abund = [float(sss) for sss in ss[2:]]

    s = fw.readline()
    ss = s.split()
    logew = [float(sss) for sss in ss[2:]]

    s = fw.readline()
    ss = s.split()
    ew = [10*float(sss) for sss in ss]

    s = fw.readline()
    ss = s.split()
    depth = [float(sss) for sss in ss[1:]]

    s = fw.readline()
    ss = s.split()
    resid = [float(sss) for sss in ss[1:]]

    s = fw.readline()
    ss = s.split()
    contin = float(ss[1])
  
    fw.close()
    
    output = {'abund': abund, 'logew': logew, 'ew': ew, 
            'depth': depth, 'resid': resid, 'contin': contin}
    
    
    return output
    
    
    
def ewlst(atmname, linelst, logvt=0.300, ofile=None):
# List equivalent widths for lines in 'linelst'. 
# Also includes information on residual depth and HFS*ISO weights.
# Calculations are done with WIDTH9
#
    extlst = ['I','II','III','IV','V','VI','VII','VIII','IX','X']
    
    if ofile is None:
        print("# Lambda     loggf      E       Code  f(HFS*ISO) Resid     EW   Species ")
    else:
        print("Writing line data to %s" % ofile)
        fout = open(ofile,'w')
        fout.write("# Lambda     loggf      E       Code  f(HFS*ISO) Resid     EW   Species \n")

    
    with open(linelst,'r') as f:
        for l in f:
            ftmp = open('linestmp.lst','w')
            ftmp.write(l)
            ftmp.close()
            lam  = float(l[0:11])*10
            loggf = float(l[11:18])
            E1 = float(l[24:36])
            E2 = float(l[52:64])
            E = min(E1, E2)
            
            elem = float(l[19:24])
            loghfs = float(l[109:115])
            logiso = float(l[118:124])
            fhfsiso = 10**(loghfs+logiso)
            
            eid = int(elem)
            eion = int((elem - eid)*100.1)
            if (eid == 1):
                name = 'H'
            elif (eid == 2):
                name = 'He'
            else:
                for kk in absetup.stdabun:
                    if (kk[1] == eid): name = kk[0]
            
            if (eion < 10):
                ext = extlst[eion]
            else:
                ext = '*'
    
            
            ewdat = calcew(atmname, elem, lam, nablog=1, minlog=0., dablog=0., logvt=logvt, lines='linestmp.lst')
    #        print ewdat
            if ofile is None:
                print("%10.3f %7.3f %12.3f %5.2f   %5.3f   %6.4f %7.1f  %2s %-5s" % (lam, loggf, E, elem, fhfsiso, ewdat['resid'][0], ewdat['ew'][0], name, ext))
            else:
                fout.write("%10.3f %7.3f %12.3f %5.2f   %5.3f   %6.4f %7.1f  %2s %-5s\n" % (lam, loggf, E, elem, fhfsiso, ewdat['resid'][0], ewdat['ew'][0], name, ext))
                fout.flush()

    
    if ofile is not None:
        fout.close()
        print("Done!")
