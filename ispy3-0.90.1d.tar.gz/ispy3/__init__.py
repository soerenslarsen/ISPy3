import sys
from .version import __version__

if sys.version_info[0] < 3:
    raise Exception("This version of ISPY requires Python 3")
