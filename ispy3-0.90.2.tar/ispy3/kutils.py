from . import utils
import matplotlib.pyplot as plt

def pconv(fname):
    f = open(fname,'r')
    s = f.readline()
    j = 1

    while (s != ''):
        if ('ITERATION' in s):
            print s
            s = f.readline()
            s = f.readline()
            s = f.readline()
            ss = s.split()

            rhox, temp, tauros = [], [], []
            cont = True
            while (cont):
                rhox.append(float(ss[1]))
                temp.append(float(ss[2]))
                tauros.append(float(ss[8]))
                s = f.readline()
                ss = s.split()
#                if (s == ''):
#                   cont = False
#                elif (s[0] == '1'):
#                   cont = False
                if len(ss) < 11: cont = False

            plt.semilogx(rhox, temp, label='%d' % j)
            j += 1

        s = f.readline()

    f.close()
    plt.xlabel('RHOX')
    plt.ylabel('Temperature')
    plt.legend()
    plt.show()


