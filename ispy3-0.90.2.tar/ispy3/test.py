# import numpy as np
# import matplotlib.pyplot as plt

import os
import kurucz
import syntmoog
import abutils

def test():
    reload(kurucz)
    reload(syntmoog)
    reload(abutils)
    
#    kurucz.mkodf(-1.1)
#    kurucz.mkatm(10000., 4.3, -1.1, 'm11t10000g43')
#    syntmoog.kur2moog('m11t10000g43.dat','m11t10000g43.atm', 2.0, -1.1)
#    syntmoog.linelst([4800., 5000.],'linelist.txt')
#    syntmoog.moogspec(-1.1, 'm11t10000g43.dat', 'm11t10000g43.moog', synlimits=[4800., 5000., 0.1, 20], linelist='linelist.txt')

#    syntmoog.linelst([4850., 4900.],'linelist.txt')

#    syntmoog.moogew(-1.1, 'm11t4100g18.dat', 'm11t4100g18.ew', synlimits=[4850., 4900., 0.1, 20], linelist='linelist.txt')
#    syntmoog.moogew(-1.1, 'm11t10000g43.dat', 'm11t10000g43.ew', synlimits=[4850., 4900., 0.1, 20], linelist='linelist.txt')
#    syntmoog.sumew(['m11t4100g18.ew','m11t10000g43.ew'],[1., 2.], 'test.txt')

#    print kurucz.vi2teff(1.5, 4.0, 0)
#    print kurucz.vi2teff(1.5, 4.0, -0.5)
#    print kurucz.vi2teff(1.5, 4.0, -1.0)
#    print kurucz.vi2teff(1.5, 4.0, -1.5)
#    print kurucz.vi2teff(1.5, 4.0, 0)
#    print kurucz.vi2teff(0.72, 4.4, 0)

#    print kurucz.interp_col(11, 1, 4.0, -1.5, 1.50)
#    print kurucz.interp_col(11, 1, 4.4,  0.0, 0.72)
    
#    print kurucz.teff2bc(5765., 4.4, 0.0)
#    print kurucz.obs2phys(0.72, 4.82, 0.0, 1.0)
#    print kurucz.obs2phys(1.75, -5.60, -0.4, 12.4)

    abutils.cmd2spec('vi.txt','testspec.moog', [5000., 5100., 0.01, 5.0], -2.2)
 
#    abutils.cmd2spec('Fornax5.vi','Fornax5.spec', [5000., 5200., 0.01, 5.0], -2.2)
#    abutils.smoothspec('Fornax5.spec','Fornax5sm.spec',0.1)
    
#    abutils.cmd2spec('Fornax5.vi','F5_4400-4600.spec', 'F5_4400-4600.ew', [4400., 4600., 0.01, 5.0], -2.2, existing_atm=True)
#    abutils.smoothspec('F5_4400-4600.spec','F5sm_4400-4600.spec',0.1)
  
#    abutils.cmd2spec('Fornax5.vi','F5_4600-4800.spec', 'F5_4600-4800.ew', [4600., 4800., 0.01, 5.0], -2.2, existing_atm=True)
#    abutils.smoothspec('F5_4600-4800.spec','F5sm_4600-4800.spec',0.1)
    
#    abutils.cmd2spec('Fornax5.vi','F5_4800-5000.spec', 'F5_4800-5000.ew', [4800., 5000., 0.01, 5.0], -2.2, existing_atm=True)
#    abutils.smoothspec('F5_4800-5000.spec','F5sm_4800-5000.spec',0.1)

#    abutils.cmd2spec('Fornax5.vi','F5_5000-5200.spec', 'F5_5000-5200.ew', [5000., 5200., 0.01, 5.0], -2.2, existing_atm=True)
#    abutils.smoothspec('F5_5000-5200.spec','F5sm_5000-5200.spec',0.1)

#    abutils.cmd2spec('Fornax5.vi','F5_5200-5400.spec', 'F5_5200-5400.ew', [5200., 5400., 0.01, 5.0], -2.2, existing_atm=True)
#    abutils.smoothspec('F5_5200-5400.spec','F5sm_5200-5400.spec',0.1)

#    abutils.cmd2spec('Fornax5.vi','F5_5400-5600.spec', 'F5_5400-5600.ew', [5400., 5600., 0.01, 5.0], -2.2, existing_atm=True)
#    abutils.smoothspec('F5_5400-5600.spec','F5sm_5400-5600.spec',0.1)

#    abutils.cmd2spec('Fornax5.vi','F5_5600-5800.spec', 'F5_5600-5800.ew', [5600., 5800., 0.01, 5.0], -2.2, existing_atm=True)
#    abutils.smoothspec('F5_5600-5800.spec','F5sm_5600-5800.spec',0.1)
    
#    abutils.cmd2spec('Fornax5.vi','F5_5800-6000.spec', 'F5_5800-6000.ew', [5800., 6000., 0.01, 5.0], -2.2, existing_atm=True)
#    abutils.smoothspec('F5_5800-6000.spec','F5sm_5800-6000.spec',0.1)

