from . import absetup
from . import __version__
import os
import stat
import shutil
import subprocess
import math
import logging
import math
import numpy as np

# Utilities for Turbospectrum NLTE

nltedir = absetup.catpref+'/cats/NLTE-TS/'           # Data for NLTE

# Data needed for NLTE analysis

NLTEelem = [
  [1, 'H',  'nlte', 'atom.h20', 'auxData_H_MARCS_May-10-2021.txt', 'NLTEgrid_H_MARCS_May-10-2021.bin'],
#  [8, 'O', 'nlte', 'atom.o41f', 'auxData_O_MARCS_May-21-2021.txt', 'NLTEgrid4TS_O_MARCS_May-21-2021.bin'],
#  [11, 'Na', 'nlte', 'atom.na102', 'auxData_Na_MARCS_Feb-20-2022.dat', 'NLTEgrid4TS_NA_MARCS_Feb-20-2022.bin'],
#  [12, 'Mg', 'nlte', 'atom.mg86b', 'auxData_Mg_MARCS_Jun-02-2021.dat', 'NLTEgrid4TS_Mg_MARCS_Jun-02-2021.bin'],
#  [14, 'Si', 'nlte', 'atom.si340', 'auxData_Si_MARCS_Feb-13-2022.dat', 'NLTEgrid4TS_Si_MARCS_Feb-13-2022.bin'],
#  [20, 'Ca', 'nlte', 'atom.ca105b', 'auxData_Ca_MARCS_Jun-02-2021.dat', 'NLTEgrid4TS_Ca_MARCS_Jun-02-2021.bin'],
#  [22, 'Ti', 'nlte', 'atom.ti503', 'auxData_TI_MARCS_Feb-21-2022.dat', 'NLTEgrid4TS_TI_MARCS_Feb-21-2022.bin'],
#  [25, 'Mn', 'nlte', 'atom.mn281kbc', 'auxData_MN_MARCS_Mar-15-2023.dat', 'NLTEgrid4TS_MN_MARCS_Mar-15-2023.bin'],
  [26, 'Fe', 'nlte', 'atom.fe607a', 'auxData_Fe_MARCS_May-07-2021.dat', 'NLTEgrid4TS_Fe_MARCS_May-07-2021.bin'],
#  [27, 'Co', 'nlte', 'atom.co247', 'auxData_CO_MARCS_Mar-15-2023.dat', 'NLTEgrid4TS_CO_MARCS_Mar-15-2023.bin'],
#  [28, 'Ni', 'nlte', 'atom.ni538qm', 'auxData_Ni_MARCS_Jan-21-2022.txt', 'NLTEgrid4TS_Ni_MARCS_Jan-31-2022.bin'],
#  [38, 'Sr', 'nlte', 'atom.sr191', 'auxData_Sr_MARCS_Mar-15-2023.dat', 'NLTEgrid4TS_Sr_MARCS_Mar-15-2023.bin'],
#  [39, 'Y',  'nlte', 'atom.y423',  'auxData_Y_MARCS_Mar-27-2023.dat',  'output_NLTEgrid4TS_Y_MARCS_Mar-27-2023_combined.bin'],
#  [56, 'Ba', 'nlte', 'atom.ba111', 'auxData_Ba_MARCS_May-10-2021.txt', 'NLTEgrid_Ba_MARCS_May-10-2021.bin'],
]

def tweakDC(odcfile, twkfile, abun):
#
# Tweak the reference abundance in departure coefficient file
#
    f = open(odcfile, 'r') 
    fo = open(twkfile, 'w')
    l = 0
    s = f.readline()

    while (len(s) > 0):
        if (s[0] != '#'): l += 1
        if l==1:
            fo.write("  %6.3f\n" % abun)
            print("Abundance changed from %6.3f to %6.3f in %s\n" % (float(s), abun, odcfile))
            logging.debug("Abundance changed from %6.3f to %6.3f in %s\n" % (float(s), abun, odcfile))
        else:
            fo.write("%s" % s)
        s = f.readline()

    f.close()
    fo.close()
        

def getDC(dcfile, pointer, abund, output):
#
# Extract a single entry from the binary Departure Coefficients file
#
    with open(dcfile, 'rb') as f:
        f.seek(pointer-1)
        atmosStr = f.readline(500)
        ndep = int.from_bytes(f.read(4), byteorder='little')
        nk = int.from_bytes(f.read(4), byteorder='little')
        tau  = np.log10(np.fromfile(f, count = ndep, dtype='f8'))
        depart = np.fromfile(f, dtype='f8', count=ndep*nk).reshape(nk, ndep)

    print(str(atmosStr[-72:]))
    print(ndep, nk)

    fout = open(output,'w')

    for i in range(8): fout.write('# parameter 1.0 1.0\n')
    fout.write("%0.3f\n" % abund)
    fout.write("%d\n" % ndep)
    fout.write("%d\n" % nk)
    for t in tau:
        fout.write("%8.4f\n" % t)
    for i in range(ndep):
        for j in range(nk):
            fout.write("%11.5E " % (depart[j][i])) 
        fout.write('\n') 

    fout.close()



def intpDC(teff, logg, mh, mstar, atmbase, workdir='.', atoms=[], abun=[], 
           wait=True):

# Call the 'interpol_modeles_nlte' programme supplied with TurbospectrumNLTE.
# This will interpolate in the precomputed grid of NLTE departure coefficients
# for each element and produce a file with departure coefficients for the
# desired stellar parameters. An interpolated Marcs atmosphere file will 
# also be generated.
# Currently the NLTE DC grid is only available for Standard Composition
# Marcs models.

    spherical = True
    mass = 1.
    vturb = 2.

    if (logg > 3): 
        spherical = False
        mass = 0.
        vturb = 1.

    fez = 0.
    if ('Fe' in atoms):
        fez = abun[atoms.index('Fe')]
    feh = mh + fez

    atmdir = absetup.catpref+'/cats/NLTE-TS/atmospheres/marcs_standard_comp'

    print("TSNLTE.INTPDC:")
    print("Teff=%0.1f, logg=%0.2f, [Fe/H]=%0.2f, mstar=%0.2f" % (teff, logg, feh, mstar))
    logging.info("TSNLTE.INTPDC:")
    logging.info('Finding departure coefficients for Teff=%0.1f, Logg=%0.2f, [Fe/H]=%0.2f' % (teff, logg, feh))

    # Set up the interpolation script

    cwd = os.getcwd()
    fi = open(workdir+'/interpol_nlte.com','w')
    fi.write('#!/bin/bash\n')
    fi.write('cd '+workdir+'\n')

    # Loop over all NLTE elements
    
    for _NLTEelem in NLTEelem:        # Deal with one NLTE element at a time
        elem = _NLTEelem[1]
        print("Now doing %s.." % elem)
        logging.info("Now doing %s.." % elem)

        auxfile = absetup.catpref+'/cats/NLTE-TS/dep-grids/'+elem+'/'+_NLTEelem[4]
        dcfile  = absetup.catpref+'/cats/NLTE-TS/dep-grids/'+elem+'/'+_NLTEelem[5]

        # Read Marcs model parameters from the 'aux' file

        idlst = []
        tefflst = []
        logglst = []
        fehlst = []
        ptrlst = []
        naux = 0
        with open(auxfile, 'r') as f:
            for s in f:
                ss = s.split()
                if (s[0] != '#'):
                    naux += 1
                    _id = ss[0][1:-1]
                    _mass = float(ss[5])
                    _vt   = float(ss[6])
                    if (_mass == mass) and (_vt == vturb):
                        idlst.append(_id)
                        tefflst.append(float(ss[1]))
                        logglst.append(float(ss[2]))
                        fehlst.append(float(ss[3]))
                        ptrlst.append(int(ss[8]))

        tefflst = np.array(tefflst)
        logglst = np.array(logglst)
        fehlst = np.array(fehlst)
        ptrlst = np.array(ptrlst)

        # Unique Teff values
   
        teffunq = np.unique(tefflst)

        if (teff < min(teffunq)) or (teff > max(teffunq)):
            print("ERROR: Requested Teff outside available range (%0.0f K < Teff < %0.0f K)" % (min(teffunq), max(teffunq)))
            logging.info("ERROR: Requested Teff outside available range (%0.0f K < Teff < %0.0f K)" % (min(teffunq), max(teffunq)))
            raise Exception('Requested Teff outside available range')

        # Find closest Teff on grid

        tbest = teffunq[0]
        ii = itbest = 0
        for ti in teffunq:
            if abs(ti-teff) < abs(tbest-teff):
                tbest = ti
                itbest = ii
            ii += 1

        # Find 2nd-best matching Teff on grid
   
        t2best = tbest
        if (tbest > teff):
            if (itbest > 0): t2best = teffunq[itbest-1]
            Tefflow = t2best
            Teffup  = tbest
        else:
            if (itbest < len(teffunq)-1): t2best = teffunq[itbest+1]
            Tefflow = tbest
            Teffup  = t2best

        print("  Requested Teff=%0.0f K" % teff)
        print("  Bracketing Grid Teff values: %0.0f K and %0.0f K" % (Tefflow, Teffup) )
        logging.info("  Requested Teff=%0.0f K" % teff)
        logging.info("  Bracketing Grid Teff values: %0.0f K and %0.0f K" % (Tefflow, Teffup) )

        # Find the logg values bracketing (or closest to) the requested value

        wtbest = np.where(tefflst == tbest)
        loggunq = np.unique(logglst[wtbest])

        print("  Unique logg values for Teff=%0.0f K: " % tbest, end='')
        print(loggunq)

        loggbest = loggunq[0]
        ii = iloggbest = 0
        for _logg in loggunq:
            if abs(_logg-logg) < abs(loggbest-logg):
                loggbest = _logg
                iloggbest = ii
            ii += 1
    
        logg2best = loggbest       # Find 2nd-best matching logg
        if (loggbest > logg):
            if (iloggbest > 0): logg2best = loggunq[iloggbest-1]
        else:
            if (iloggbest < len(loggunq)-1): logg2best = loggunq[iloggbest+1]

        # Find closest [Fe/H] match
        # We may fall back on this later.

        print("  Best logg=%0.2f at this Teff" % loggbest)

        wg = np.where((logglst[wtbest] == loggbest))
        fehw = fehlst[wtbest][wg]
        ptrw = ptrlst[wtbest][wg]

        fehbest = fehw[0]
        ptrbest = ptrw[0]
        for _feh,_ptr in zip(fehw,ptrw):
            if abs(_feh-feh) < abs(fehbest-feh):
                fehbest = _feh
                ptrbest = _ptr

        print("  Best [Fe/H]=%0.2f at this logg,Teff" % fehbest)

        # Check if requested logg falls within interpolation range.
        # If not, use closest matching grid point.
        # If yes, attempt to set up interpolation grid. This may still fail if
        # some corners of the cube fall outside the grid.

        print("  Requested logg=%0.2f" % logg)
        logging.info("  Requested logg=%0.2f" % logg)

        if (logg < min(loggbest, logg2best)) or (logg > max(loggbest, logg2best)):
            print("  ** Requested logg outside available range (%0.3f < logg < %0.3f)" % (min(loggunq), max(loggunq)))
            logging.info("  ** Requested logg outside available range (%0.3f < logg < %0.3f)" % (min(loggunq), max(loggunq)))
            models = [None]
        else:
            print("  Bracketing Grid logg values: %0.2f and %0.2f" % (min(loggbest, logg2best), max(loggbest,logg2best)))
            logging.info("  Bracketing Grid logg values: %0.2f and %0.2f" % (min(loggbest, logg2best), max(loggbest,logg2best)))

            # Find bracketing [Fe/H] values. 
            # If these are matched at all Teff, logg combinations then we're good.    

            print("  Requested [Fe/H]=%0.2f" % feh)
            logging.info("  Requested [Fe/H]=%0.2f" % feh)

            fehlow, fehup = min(fehw), max(fehw)

            if (feh < fehlow) or (feh > fehup):
                print("Requested [Fe/H] outside available range (%0.3f < [Fe/H] < %0.3f)" % (fehlow, fehup))
                logging.info("Requested [Fe/H] outside available range (%0.3f < [Fe/H] < %0.3f)" % (fehlow, fehup))
                models = [None]
            else:

                for fehi in fehw:
                    if (abs(fehi-feh) < abs(fehlow-feh)) and (fehi <= feh):
                        fehlow = fehi
                    if (abs(fehi-feh) < abs(fehup-feh)) and (fehi >= feh):
                        fehup = fehi

                print("  Bracketing Grid [Fe/H] values: %0.2f and %0.2f" % (fehlow, fehup))
                logging.info("  Bracketing Grid [Fe/H] values: %0.2f and %0.2f" % (fehlow, fehup))
                # Find the Grid entries for each (Teff, logg, LogZ) combination

                models = []

                for _teff in (Tefflow, Teffup):
                    for _logg in (min(loggbest,logg2best), max(loggbest,logg2best)):
                        for _feh in (fehlow, fehup):
                            wm = np.where((tefflst == _teff) 
                                        & (logglst == _logg) 
                                        & (fehlst == _feh))
                            if (len(wm[0]) > 0):
                                iptr = ptrlst[wm[0][0]]
                                print("  Teff=%4d logg=%5.2f feh=%5.2f: ptr=%d" % 
                                       (_teff, _logg, _feh, iptr))
                                models.append(idlst[wm[0][0]])
                            else:
                                print("  Could not find Grid entry matching Teff=%4d logg=%5.2f feh=%5.2f" % (_teff, _logg, _feh))
                                logging.info("  Could not find Grid entry matching Teff=%4d logg=%5.2f feh=%5.2f" % (_teff, _logg, _feh))
                                models.append(None)

        # Find the H fraction (and number of elements to print)
        # Note - Turbospectrum normalises abundances to H, not total - so
        # we just need to figure out the Solar H abundance

        fhe = 0.07834      # Corresponds to Y=0.248; Grevesse & Sauval 1998
        fz0 = 0

        for aa in absetup.stdabun:
            ielem = aa[1]
            iabun = aa[2]
            fz0 = fz0 + 10**iabun

            if (aa[0] == elem):
                eabunref = iabun

        fh0 = 1 - fhe - fz0
        logfh0 = math.log10(fh0)

        if (elem == 'H'):
            aburef = 12
        else:
            eda = 0.
            if (elem in atoms):
                eda = abun[atoms.index(elem)]
            aburef = 12 + mh + eabunref + eda - logfh0

#        # Set up the interpolation script
#
#        cwd = os.getcwd()
#        fi = open(workdir+'/interpol_nlte.com','w')
#        fi.write('#!/bin/bash\n')
#        fi.write('cd '+workdir+'\n')

        fi.write(absetup.binpath+'/interpol_modeles_nlte << EOF\n')

        if (None in models):    # If at least one model wasn't available,
                                # use the closest model on the grid
            wm = np.where(ptrlst == ptrbest)
            fnbest = idlst[wm[0][0]]
            print("  Failed to set up interpolation grid.")
            print("  Using closest point, %s, ptr=%d" % (fnbest, ptrbest))
            logging.info("  Failed to set up interpolation grid.")
            logging.info("  Using closest point, %s, ptr=%d" % (fnbest, ptrbest))
#            getDC(dcfile, ptrbest, aburef, "%s/%s_%s_coef.dat" % (cwd, atmbase, elem))
            # Just give the same model as input eight times.
            # Interpol_modeles_nlte will still interpolate in abundance
            # to get the requested 'aburef' for the specified element

            for i in range(1,9):
                fi.write('\'%s/%s.mod\'\n' % (atmdir,fnbest))  
        else:
            print("  Interpolating in these Grid points:")
            logging.info("  Interpolating in these Grid points:")
            for _model in models:
                print("    %s" % _model)
                logging.info("    %s" % _model)

            for _model in models:
                fi.write('\'%s/%s.mod\'\n' % (atmdir,_model))  # List of models to interpolate

        fi.write('\'%s/%s.marcs\'\n' % (cwd, atmbase))     # Output interpolated atmosphere
        fi.write('\'%s/interp.out2\'\n' % (workdir))       # Output 'out2'
        fi.write('\'%s/%s_%s_coef.dat\'\n' % (cwd, atmbase, elem))  # Output Departure Coeffs.
        fi.write('\'%s\'\n' % (dcfile))                    # NLTE DC binary file
        fi.write('\'%s\'\n' % (auxfile))                   # Aux file list
        fi.write('%d\n' % naux)                            # Aux file length
        fi.write('%0.1f\n' % teff)
        fi.write('%0.3f\n' % logg)
        fi.write('%0.3f\n' % feh)

        fi.write('%5.3f\n' % aburef) 
        fi.write('.false.\n')                              # Plot comparison model?
        fi.write('.false.\n')                              # Marcs binary?
        fi.write('\'dummy\'\n')
        fi.write('EOF\n')

    fi.close()
    os.chmod(workdir+'/interpol_nlte.com',stat.S_IXUSR | stat.S_IRUSR | stat.S_IWUSR)
#    os.system("bash -c 'source %s/interpol_nlte.com'" % (workdir))
#    if (elem=='Fe'): tweakDC("%s/%s_Fe_coef.dat" % (cwd, atmbase), aburef)

    p = subprocess.Popen(workdir+'/interpol_nlte.com')

    if (wait):
        os.waitpid(p.pid,0)
    else:
        return p


